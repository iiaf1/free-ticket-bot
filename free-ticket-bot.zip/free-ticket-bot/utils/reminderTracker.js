/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

// خريطة بالذاكرة: channelId -> timeoutId
const timers = new Map();

/** يجدول تذكير بعد delayMs من الآن لهذا الروم (يلغي أي تذكير سابق له أولاً) */
function scheduleReminder(channelId, delayMs, callback) {
    clearReminder(channelId);
    const timeoutId = setTimeout(() => {
        timers.delete(channelId);
        callback();
    }, delayMs);
    timers.set(channelId, timeoutId);
}

/** يلغي أي تذكير مجدول لهذا الروم */
function clearReminder(channelId) {
    const existing = timers.get(channelId);
    if (existing) {
        clearTimeout(existing);
        timers.delete(channelId);
    }
}

module.exports = { scheduleReminder, clearReminder };
