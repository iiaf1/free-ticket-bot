/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DB_DIR = path.join(__dirname, '..', 'data');
const DB_PATH = path.join(DB_DIR, 'settings.json');

function ensureDB() {
    if (!fs.existsSync(DB_DIR)) fs.mkdirSync(DB_DIR, { recursive: true });
    if (!fs.existsSync(DB_PATH)) fs.writeFileSync(DB_PATH, JSON.stringify({}, null, 2), 'utf-8');
}

function readDB() {
    ensureDB();
    try {
        const raw = fs.readFileSync(DB_PATH, 'utf-8');
        return JSON.parse(raw || '{}');
    } catch (err) {
        console.error('[DB] خطأ أثناء قراءة قاعدة البيانات:', err);
        return {};
    }
}

function writeDB(data) {
    ensureDB();
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
}

/** يرجع إعدادات السيرفر، أو كائن افتراضي إن لم توجد */
function getGuildSettings(guildId) {
    const db = readDB();
    return db[guildId] || {
        logChannelId: null,
        ticketCounter: 0,
        ticketTypes: [], // [{ id, label, emoji, description, categoryId, supportRoleId }]
        openTickets: {} // channelId -> { userId, openedAt, ticketNumber, typeId, typeLabel }
    };
}

function setGuildSettings(guildId, settings) {
    const db = readDB();
    db[guildId] = { ...getGuildSettings(guildId), ...settings };
    writeDB(db);
    return db[guildId];
}

function addOpenTicket(guildId, channelId, ticketData) {
    const db = readDB();
    if (!db[guildId]) db[guildId] = getGuildSettings(guildId);
    if (!db[guildId].openTickets) db[guildId].openTickets = {};
    db[guildId].openTickets[channelId] = ticketData;
    writeDB(db);
}

function removeOpenTicket(guildId, channelId) {
    const db = readDB();
    if (db[guildId] && db[guildId].openTickets) {
        delete db[guildId].openTickets[channelId];
        writeDB(db);
    }
}

function incrementTicketCounter(guildId) {
    const db = readDB();
    if (!db[guildId]) db[guildId] = getGuildSettings(guildId);
    db[guildId].ticketCounter = (db[guildId].ticketCounter || 0) + 1;
    writeDB(db);
    return db[guildId].ticketCounter;
}

/** يرجع كل أنواع التذاكر المُعرّفة لهذا السيرفر */
function getTicketTypes(guildId) {
    const settings = getGuildSettings(guildId);
    return settings.ticketTypes || [];
}

/** يضيف نوع تذكرة جديد ويرجعه (مع id فريد) */
function addTicketType(guildId, typeData) {
    const db = readDB();
    if (!db[guildId]) db[guildId] = getGuildSettings(guildId);
    if (!db[guildId].ticketTypes) db[guildId].ticketTypes = [];

    const newType = {
        id: crypto.randomUUID(),
        label: typeData.label,
        emoji: typeData.emoji || null,
        description: typeData.description || '',
        categoryId: typeData.categoryId,
        supportRoleId: typeData.supportRoleId,
    };

    db[guildId].ticketTypes.push(newType);
    writeDB(db);
    return newType;
}

/** يحذف نوع تذكرة بواسطة id أو label (يرجع true إذا حُذف) */
function removeTicketType(guildId, idOrLabel) {
    const db = readDB();
    if (!db[guildId] || !db[guildId].ticketTypes) return false;

    const before = db[guildId].ticketTypes.length;
    db[guildId].ticketTypes = db[guildId].ticketTypes.filter(
        (t) => t.id !== idOrLabel && t.label !== idOrLabel
    );
    writeDB(db);
    return db[guildId].ticketTypes.length < before;
}

function getTicketTypeById(guildId, typeId) {
    const types = getTicketTypes(guildId);
    return types.find((t) => t.id === typeId) || null;
}

module.exports = {
    getGuildSettings,
    setGuildSettings,
    addOpenTicket,
    removeOpenTicket,
    incrementTicketCounter,
    getTicketTypes,
    addTicketType,
    removeTicketType,
    getTicketTypeById,
};
