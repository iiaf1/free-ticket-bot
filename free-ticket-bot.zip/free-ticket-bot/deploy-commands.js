/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { REST, Routes } = require('discord.js');

const { TOKEN, CLIENT_ID, GUILD_ID } = process.env;

if (!TOKEN || !CLIENT_ID) {
    console.error('❌ تأكد من ضبط TOKEN و CLIENT_ID في ملف .env');
    process.exit(1);
}

const commands = [];
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((file) => file.endsWith('.js'));

for (const file of commandFiles) {
    const command = require(path.join(commandsPath, file));
    if ('data' in command && 'execute' in command) {
        commands.push(command.data.toJSON());
    } else {
        console.warn(`⚠️ الملف ${file} ناقص خاصية data أو execute.`);
    }
}

const rest = new REST().setToken(TOKEN);

(async () => {
    try {
        console.log(`🔄 جاري تسجيل ${commands.length} أمر سلاش...`);

        let data;
        if (GUILD_ID) {
            // تسجيل فوري على سيرفر واحد (مفيد أثناء التطوير)
            data = await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), {
                body: commands,
            });
            console.log(`✅ تم تسجيل ${data.length} أمر بنجاح على السيرفر (GUILD_ID) بشكل فوري.`);
        } else {
            // تسجيل عالمي (قد يستغرق حتى ساعة للانتشار على كل السيرفرات)
            data = await rest.put(Routes.applicationCommands(CLIENT_ID), {
                body: commands,
            });
            console.log(`✅ تم تسجيل ${data.length} أمر بنجاح بشكل عالمي (قد يستغرق الانتشار حتى ساعة).`);
        }
    } catch (error) {
        console.error('❌ فشل تسجيل الأوامر:', error);
    }
})();
