/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const { Events } = require('discord.js');
const db = require('../utils/db');
const { scheduleReminder, clearReminder } = require('../utils/reminderTracker');

const REMINDER_DELAY_MS = 5 * 60 * 1000; // 5 دقايق

module.exports = {
    name: Events.MessageCreate,
    async execute(message) {
        if (message.author.bot) return;
        if (!message.guild) return;

        const settings = db.getGuildSettings(message.guild.id);
        const ticketData = (settings.openTickets || {})[message.channel.id];
        if (!ticketData) return; // مو روم تذكرة، تجاهل

        // ===== صاحب التذكرة رد بنفسه -> ألغِ أي تذكير معلّق =====
        if (message.author.id === ticketData.userId) {
            clearReminder(message.channel.id);
            return;
        }

        const ticketType = db.getTicketTypeById(message.guild.id, ticketData.typeId);
        if (!ticketType) return;

        // ===== تحقق إن الكاتب من فريق الدعم المسؤول عن هذا النوع =====
        const member = message.member;
        if (!member || !member.roles.cache.has(ticketType.supportRoleId)) return;

        // فريق الدعم رد -> جدولة تذكير بعد 5 دقايق في حال ما رد صاحب التذكرة
        scheduleReminder(message.channel.id, REMINDER_DELAY_MS, async () => {
            try {
                const currentSettings = db.getGuildSettings(message.guild.id);
                const currentTicket = (currentSettings.openTickets || {})[message.channel.id];
                if (!currentTicket) return; // التذكرة انقفلت أو انحذفت قبل ما يفوت الوقت

                const openerUser = await message.client.users.fetch(currentTicket.userId).catch(() => null);
                if (!openerUser) return;

                const channelLink = `https://discord.com/channels/${message.guild.id}/${message.channel.id}`;

                await openerUser
                    .send({
                        content:
                            `🔔 الدعم الفني رد عليك في تذكرتك رقم #${currentTicket.ticketNumber ?? '-'} (${currentTicket.typeLabel || ''}).\n` +
                            `يرجى التوجه للتذكرة للمتابعة: ${channelLink}`,
                    })
                    .catch(() => {}); // تجاهل إذا كانت الخاص مقفلة عنده
            } catch (err) {
                console.error('[reminder] خطأ أثناء إرسال تذكير المتابعة:', err);
            }
        });
    },
};
