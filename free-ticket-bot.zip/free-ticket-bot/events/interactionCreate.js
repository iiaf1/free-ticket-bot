/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const {
    Events,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
} = require('discord.js');
const { createTicketChannel, closeTicket } = require('../utils/ticketManager');
const db = require('../utils/db');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        try {
            // ===== الإكمال التلقائي (Autocomplete) =====
            if (interaction.isAutocomplete()) {
                const command = interaction.client.commands.get(interaction.commandName);
                if (!command || !command.autocomplete) return;
                await command.autocomplete(interaction);
                return;
            }

            // ===== أوامر السلاش =====
            if (interaction.isChatInputCommand()) {
                const command = interaction.client.commands.get(interaction.commandName);
                if (!command) return;
                await command.execute(interaction);
                return;
            }

            // ===== قائمة اختيار نوع التذكرة =====
            if (interaction.isStringSelectMenu() && interaction.customId === 'select_ticket_type') {
                await interaction.deferReply({ ephemeral: true });

                const typeId = interaction.values[0];

                try {
                    const { channel, alreadyOpen } = await createTicketChannel(
                        interaction.guild,
                        interaction.member,
                        typeId
                    );

                    await interaction.editReply({
                        content: alreadyOpen
                            ? `لديك بالفعل تذكرة مفتوحة من هذا النوع: ${channel}`
                            : `✅ تم فتح تذكرتك: ${channel}`,
                    });
                } catch (err) {
                    await interaction.editReply({
                        content: `❌ حدث خطأ: ${err.message}`,
                    });
                }
                return;
            }

            // ===== زر: طلب إغلاق التذكرة (يعرض تأكيد) =====
            if (interaction.isButton() && interaction.customId === 'close_ticket') {
                const confirmEmbed = new EmbedBuilder()
                    .setColor(0xfee75c)
                    .setDescription('⚠️ هل أنت متأكد من رغبتك بإغلاق هذه التذكرة؟');

                const row = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('confirm_close')
                        .setLabel('تأكيد الإغلاق')
                        .setStyle(ButtonStyle.Danger),
                    new ButtonBuilder()
                        .setCustomId('cancel_close')
                        .setLabel('إلغاء')
                        .setStyle(ButtonStyle.Secondary)
                );

                await interaction.reply({ embeds: [confirmEmbed], components: [row] });
                return;
            }

            // ===== زر: تأكيد الإغلاق =====
            if (interaction.isButton() && interaction.customId === 'confirm_close') {
                const settings = db.getGuildSettings(interaction.guild.id);
                const isTicket = Object.prototype.hasOwnProperty.call(
                    settings.openTickets || {},
                    interaction.channel.id
                );

                if (!isTicket) {
                    return interaction.update({
                        content: '❌ هذه التذكرة غير موجودة في السجل، لا يمكن إغلاقها تلقائياً.',
                        embeds: [],
                        components: [],
                    });
                }

                await interaction.update({
                    content: '🔒 جاري إغلاق التذكرة وحفظ السجل... سيتم حذف الروم خلال ثوانٍ.',
                    embeds: [],
                    components: [],
                });

                await closeTicket(
                    interaction.channel,
                    interaction.guild,
                    interaction.user,
                    'أُغلقت عبر الزر'
                );
                return;
            }

            // ===== زر: إلغاء الإغلاق =====
            if (interaction.isButton() && interaction.customId === 'cancel_close') {
                await interaction.update({
                    content: '✅ تم إلغاء عملية الإغلاق.',
                    embeds: [],
                    components: [],
                });
                return;
            }
        } catch (error) {
            console.error('[interactionCreate] خطأ:', error);
            const errorPayload = {
                content: '❌ حدث خطأ غير متوقع أثناء تنفيذ هذا الإجراء.',
                ephemeral: true,
            };
            if (interaction.deferred || interaction.replied) {
                await interaction.followUp(errorPayload).catch(() => {});
            } else {
                await interaction.reply(errorPayload).catch(() => {});
            }
        }
    },
};
