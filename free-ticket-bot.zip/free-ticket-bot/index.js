/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

require('dotenv').config();
const fs = require('fs');
const path = require('path');
const { Client, GatewayIntentBits, Collection, Partials } = require('discord.js');

const { TOKEN } = process.env;

if (!TOKEN) {
    console.error('❌ لم يتم ضبط TOKEN في ملف .env');
    process.exit(1);
}

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
    ],
    partials: [Partials.Channel, Partials.Message],
});

// ===== تحميل الأوامر =====
client.commands = new Collection();
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter((file) => file.endsWith('.js'));

for (const file of commandFiles) {
    const command = require(path.join(commandsPath, file));
    if ('data' in command && 'execute' in command) {
        client.commands.set(command.data.name, command);
    } else {
        console.warn(`⚠️ الملف ${file} ناقص خاصية data أو execute.`);
    }
}

// ===== تحميل الأحداث =====
const eventsPath = path.join(__dirname, 'events');
const eventFiles = fs.readdirSync(eventsPath).filter((file) => file.endsWith('.js'));

for (const file of eventFiles) {
    const event = require(path.join(eventsPath, file));
    if (event.once) {
        client.once(event.name, (...args) => event.execute(...args, client));
    } else {
        client.on(event.name, (...args) => event.execute(...args, client));
    }
}

client.login(TOKEN);
