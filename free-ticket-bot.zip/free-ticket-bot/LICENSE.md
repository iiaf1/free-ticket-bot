Copyright (c) 2026 iaf1 — All rights reserved.
حقوق الملكية (c) 2026 iaf1 — جميع الحقوق محفوظة.

- هذا المشروع مجاني بالكامل.
- المشروع غير قابل للبيع، ولا يجوز بيعه أو بيع كوده أو أي نسخة معدّلة منه.
- يجوز استخدامه وتعديله لأغراض غير تجارية، بشرط إبقاء اسم المالك وهذا الإشعار.
- لا يجوز نسبة المشروع أو جزء منه لغير صاحبه.
- الاستخدام التجاري يحتاج إذن كتابي من المالك.

- This project is completely free.
- It is NOT for sale. Selling it, its source code, or any modified
  version of it is not permitted.
- You may use and modify it for non-commercial purposes, provided this
  notice and the owner's name are kept.
- You may not claim it or any part of it as your own work.
- Commercial use requires written permission from the owner.

إخلاء المسؤولية / Disclaimer:
هذا المشروع مقدَّم "كما هو" بدون أي ضمانات من أي نوع. المالك غير مسؤول عن
أي أضرار أو خسائر أو مشاكل في السيرفر أو فقدان بيانات أو ثغرات أمنية أو سوء
استخدام، والمستخدم هو المسؤول الوحيد عن استخدامه وتعديله.
This project is provided "AS IS", without warranty of any kind. The owner
is not liable for any damage, loss, server issues, data loss, security
issues, or misuse. The user is solely responsible for how it is used
and modified.

Discord: iaf0 | GitHub: https://github.com/iiaf1