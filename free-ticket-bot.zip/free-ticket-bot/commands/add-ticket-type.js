/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    ChannelType,
} = require("discord.js");
const db = require("../utils/db");

const MAX_TICKET_TYPES = 25; // حد Discord لعدد خيارات القائمة المنسدلة

module.exports = {
    data: new SlashCommandBuilder()
        .setName("add-ticket-type")
        .setDescription(
            "إضافة نوع تذكرة جديد (مثل: استفسار، مشكلة، شكوى) للوحة الاختيار",
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addStringOption((opt) =>
            opt
                .setName("الاسم")
                .setDescription(
                    "اسم نوع التذكرة كما سيظهر بالقائمة (مثال: استفسار)",
                )
                .setRequired(true)
                .setMaxLength(80),
        )
        .addChannelOption((opt) =>
            opt
                .setName("التصنيف")
                .setDescription(
                    "التصنيف (Category) الذي ستُنشأ بداخله رومات هذا النوع",
                )
                .addChannelTypes(ChannelType.GuildCategory)
                .setRequired(true),
        )
        .addRoleOption((opt) =>
            opt
                .setName("رتبة-الدعم")
                .setDescription(
                    "الرتبة التي سترى وتستطيع الرد على هذا النوع من التذاكر",
                )
                .setRequired(true),
        )
        .addStringOption((opt) =>
            opt
                .setName("الوصف")
                .setDescription(
                    "وصف قصير يظهر تحت اسم النوع بالقائمة (اختياري)",
                )
                .setRequired(false)
                .setMaxLength(100),
        )
        .addStringOption((opt) =>
            opt
                .setName("ايموجي")
                .setDescription(
                    "إيموجي يظهر بجانب اسم النوع (اختياري، مثال: ❓)",
                )
                .setRequired(false),
        ),

    async execute(interaction) {
        const settings = db.getGuildSettings(interaction.guild.id);
        const currentTypes = settings.ticketTypes || [];

        if (currentTypes.length >= MAX_TICKET_TYPES) {
            return interaction.reply({
                content: `❌ وصلت للحد الأقصى (${MAX_TICKET_TYPES} نوع). احذف نوع قديم أولاً بأمر \`/remove-ticket-type\`.`,
                ephemeral: true,
            });
        }

        const label = interaction.options.getString("الاسم");
        const category = interaction.options.getChannel("التصنيف");
        const supportRole = interaction.options.getRole("رتبة-الدعم");
        const description = interaction.options.getString("الوصف") || "";
        const emoji = interaction.options.getString("ايموجي") || null;

        if (currentTypes.some((t) => t.label === label)) {
            return interaction.reply({
                content: `❌ يوجد نوع تذكرة بنفس الاسم "${label}" مسبقاً.`,
                ephemeral: true,
            });
        }

        const newType = db.addTicketType(interaction.guild.id, {
            label,
            emoji,
            description,
            categoryId: category.id,
            supportRoleId: supportRole.id,
        });

        await interaction.reply({
            content:
                `✅ تمت إضافة نوع التذكرة **${newType.label}** ${emoji || ""}\n` +
                `- التصنيف: ${category}\n` +
                `- رتبة الدعم: ${supportRole}\n\n` +
                `لا تنسَ إرسال/تحديث اللوحة بأمر \`/send-panel\` بعد ما تخلص إضافة كل الأنواع.`,
            ephemeral: true,
        });
    },
};
