/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove')
        .setDescription('إزالة عضو من التذكرة الحالية')
        .addUserOption((opt) =>
            opt.setName('العضو').setDescription('العضو المراد إزالته من التذكرة').setRequired(true)
        ),

    async execute(interaction) {
        const settings = db.getGuildSettings(interaction.guild.id);
        const isTicket = Object.prototype.hasOwnProperty.call(
            settings.openTickets || {},
            interaction.channel.id
        );

        if (!isTicket) {
            return interaction.reply({
                content: '❌ هذا الأمر يعمل فقط داخل روم تذكرة مفتوحة.',
                ephemeral: true,
            });
        }

        const targetUser = interaction.options.getUser('العضو');

        await interaction.channel.permissionOverwrites.delete(targetUser.id);

        await interaction.reply({
            content: `✅ تمت إزالة ${targetUser} من التذكرة.`,
        });
    },
};
