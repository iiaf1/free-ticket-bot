/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
} = require('discord.js');
const db = require('../utils/db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('send-panel')
        .setDescription('إرسال لوحة فتح التذاكر (بقائمة اختيار الأنواع) في هذه القناة')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addStringOption((opt) =>
            opt.setName('العنوان').setDescription('عنوان لوحة التذاكر (اختياري)').setRequired(false)
        )
        .addStringOption((opt) =>
            opt.setName('الوصف').setDescription('وصف لوحة التذاكر (اختياري)').setRequired(false)
        ),

    async execute(interaction) {
        const settings = db.getGuildSettings(interaction.guild.id);

        if (!settings.logChannelId) {
            return interaction.reply({
                content: '❌ لازم تضبط روم السجلات أولاً بأمر `/setup-tickets`.',
                ephemeral: true,
            });
        }

        const types = db.getTicketTypes(interaction.guild.id);
        if (types.length === 0) {
            return interaction.reply({
                content: '❌ لا توجد أنواع تذاكر مُضافة بعد. أضف نوع واحد على الأقل بأمر `/add-ticket-type`.',
                ephemeral: true,
            });
        }

        const title = interaction.options.getString('العنوان') || '🎫 نظام الدعم الفني';
        const description =
            interaction.options.getString('الوصف') ||
            'اختر نوع طلبك من القائمة أدناه ليتم فتح تذكرة خاصة بك.';

        const panelEmbed = new EmbedBuilder()
            .setColor(0x5865f2)
            .setTitle(title)
            .setDescription(description)
            .setFooter({
                text: interaction.guild.name,
                iconURL: interaction.guild.iconURL() || undefined,
            })
            .setTimestamp();

        const selectMenu = new StringSelectMenuBuilder()
            .setCustomId('select_ticket_type')
            .setPlaceholder('اختر نوع التذكرة...')
            .addOptions(
                types.map((t) => {
                    const option = {
                        label: t.label,
                        value: t.id,
                        description: t.description ? t.description.slice(0, 100) : undefined,
                    };
                    if (t.emoji) option.emoji = t.emoji;
                    return option;
                })
            );

        const row = new ActionRowBuilder().addComponents(selectMenu);

        await interaction.channel.send({ embeds: [panelEmbed], components: [row] });

        await interaction.reply({
            content: `✅ تم إرسال لوحة التذاكر بنجاح وفيها ${types.length} نوع.`,
            ephemeral: true,
        });
    },
};
