/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/db');
const { closeTicket } = require('../utils/ticketManager');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('close')
        .setDescription('إغلاق تذكرة الدعم الحالية وحفظ سجلها (يجب استخدامه داخل روم التذكرة)')
        .addStringOption((opt) =>
            opt.setName('السبب').setDescription('سبب إغلاق التذكرة (اختياري)').setRequired(false)
        ),

    async execute(interaction) {
        const settings = db.getGuildSettings(interaction.guild.id);
        const isTicket = Object.prototype.hasOwnProperty.call(
            settings.openTickets || {},
            interaction.channel.id
        );

        if (!isTicket) {
            return interaction.reply({
                content: '❌ هذا الأمر يعمل فقط داخل روم تذكرة مفتوحة.',
                ephemeral: true,
            });
        }

        const reason = interaction.options.getString('السبب') || 'لا يوجد سبب محدد';

        await interaction.reply({
            content: '🔒 جاري إغلاق التذكرة وحفظ السجل... سيتم حذف الروم خلال ثوانٍ.',
        });

        await closeTicket(interaction.channel, interaction.guild, interaction.user, reason);
    },
};
