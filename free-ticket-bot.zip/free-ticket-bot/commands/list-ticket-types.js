/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../utils/db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('list-ticket-types')
        .setDescription('عرض كل أنواع التذاكر المُعرّفة حالياً بالسيرفر')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),

    async execute(interaction) {
        const types = db.getTicketTypes(interaction.guild.id);

        if (types.length === 0) {
            return interaction.reply({
                content: '📭 لا توجد أنواع تذاكر مُضافة بعد. استخدم `/add-ticket-type` لإضافة أول نوع.',
                ephemeral: true,
            });
        }

        const embed = new EmbedBuilder()
            .setColor(0x5865f2)
            .setTitle('📋 أنواع التذاكر الحالية')
            .setDescription(
                types
                    .map((t, i) => {
                        const category = interaction.guild.channels.cache.get(t.categoryId);
                        return `**${i + 1}. ${t.emoji ? t.emoji + ' ' : ''}${t.label}**\n` +
                            `> التصنيف: ${category ? category.name : 'محذوف'}\n` +
                            `> رتبة الدعم: <@&${t.supportRoleId}>\n` +
                            `> الوصف: ${t.description || '-'}`;
                    })
                    .join('\n\n')
            )
            .setFooter({ text: `${types.length} نوع مُضاف` });

        await interaction.reply({ embeds: [embed], ephemeral: true });
    },
};
