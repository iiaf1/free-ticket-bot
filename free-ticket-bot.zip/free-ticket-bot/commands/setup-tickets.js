/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const db = require('../utils/db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setup-tickets')
        .setDescription('إعداد الإعدادات العامة لنظام التذاكر (روم السجلات)')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addChannelOption((opt) =>
            opt
                .setName('روم-السجلات')
                .setDescription('الروم الذي سيتم إرسال ترانسكريبت التذاكر المغلقة إليه')
                .addChannelTypes(ChannelType.GuildText)
                .setRequired(true)
        ),

    async execute(interaction) {
        const logChannel = interaction.options.getChannel('روم-السجلات');

        db.setGuildSettings(interaction.guild.id, {
            logChannelId: logChannel.id,
        });

        await interaction.reply({
            content:
                `✅ تم ضبط روم السجلات على ${logChannel}.\n\n` +
                `**الخطوة الجاية:** أضف أنواع التذاكر (مثل استفسار / مشكلة) عن طريق:\n` +
                `\`/add-ticket-type\`\n\n` +
                `وبعد ما تضيف كل الأنواع اللي تبيها، أرسل لوحة التذاكر بأمر:\n` +
                `\`/send-panel\``,
            ephemeral: true,
        });
    },
};
