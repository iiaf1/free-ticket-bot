/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../utils/db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('remove-ticket-type')
        .setDescription('حذف نوع تذكرة موجود من لوحة الاختيار')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addStringOption((opt) =>
            opt
                .setName('الاسم')
                .setDescription('اسم نوع التذكرة المراد حذفه (كما هو مكتوب بالضبط)')
                .setRequired(true)
                .setAutocomplete(true)
        ),

    async autocomplete(interaction) {
        const focused = interaction.options.getFocused().toLowerCase();
        const types = db.getTicketTypes(interaction.guild.id);
        const filtered = types
            .filter((t) => t.label.toLowerCase().includes(focused))
            .slice(0, 25)
            .map((t) => ({ name: t.label, value: t.label }));
        await interaction.respond(filtered);
    },

    async execute(interaction) {
        const label = interaction.options.getString('الاسم');
        const removed = db.removeTicketType(interaction.guild.id, label);

        if (!removed) {
            return interaction.reply({
                content: `❌ ما لقيت نوع تذكرة باسم "${label}".`,
                ephemeral: true,
            });
        }

        await interaction.reply({
            content: `✅ تم حذف نوع التذكرة "${label}". لا تنسَ تحديث اللوحة بأمر \`/send-panel\`.`,
            ephemeral: true,
        });
    },
};
