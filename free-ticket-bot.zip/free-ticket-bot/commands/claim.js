/**
 * حقوق الملكية والترخيص (License)
 * هذا المشروع مرخص بموجب رخصة MIT - راجع ملف LICENSE.md لتفاصيل الرخصة كاملة.
 * جميع الحقوق محفوظة (c) 2026 لـ iaf0.
 *
 * للتواصل والدعم:
 * Discord: iaf0
 * GitHub: https://github.com/iiaf1
 */

const { SlashCommandBuilder, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const db = require('../utils/db');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('claim')
        .setDescription('استلام هذه التذكرة وإشعار صاحبها بأن الدعم الفني بدأ بالمتابعة'),

    async execute(interaction) {
        const settings = db.getGuildSettings(interaction.guild.id);
        const ticketData = (settings.openTickets || {})[interaction.channel.id];

        if (!ticketData) {
            return interaction.reply({
                content: '❌ هذا الأمر يعمل فقط داخل روم تذكرة مفتوحة.',
                ephemeral: true,
            });
        }

        const ticketType = db.getTicketTypeById(interaction.guild.id, ticketData.typeId);
        const isSupport =
            ticketType && interaction.member.roles.cache.has(ticketType.supportRoleId);
        const isManager = interaction.member.permissions.has(PermissionFlagsBits.ManageGuild);

        if (!isSupport && !isManager) {
            return interaction.reply({
                content: '❌ هذا الأمر مخصص لفريق الدعم الفني المسؤول عن هذه التذكرة فقط.',
                ephemeral: true,
            });
        }

        db.addOpenTicket(interaction.guild.id, interaction.channel.id, {
            ...ticketData,
            claimedBy: interaction.user.id,
            claimedByTag: interaction.user.tag,
            claimedAt: Date.now(),
        });

        const embed = new EmbedBuilder()
            .setColor(0x57f287)
            .setDescription(
                `✅ تم استلام هذه التذكرة من قبل ${interaction.user} وسيتم متابعتها الآن.`
            );

        await interaction.reply({
            content: `<@${ticketData.userId}>`,
            embeds: [embed],
        });
    },
};
